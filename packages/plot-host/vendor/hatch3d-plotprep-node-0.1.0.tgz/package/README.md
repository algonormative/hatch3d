# @hatch3d/plotprep-node

Private ESM adapter for the `plotprep` 0.1.0 native engine. This package never
contains the executable, uploads, queue behavior, or UI. The caller configures
an executable path or PATH command and owns any persistent artifact storage.
The adapter resolves the executable once to a canonical absolute executable file,
so native calls keep the same path when they run in private working directories.

```js
import { createPlotprepClient } from '@hatch3d/plotprep-node';
const client = createPlotprepClient({ executable: '/opt/hatch3d/bin/plotprep' });
const { report: inspected } = await client.inspectSvg(svgBytes);
const { bytes, report, sourceReport } = await client.prepareSvg(svgBytes, {
  sort: true,
  allowReverse: false,
});
```

Both calls accept SVG `Uint8Array`/`Buffer` and copy it before writing into a
private temporary directory. `inspectSvg` uses the native normalized-source
contract for generic SVG. `prepareSvg` always inspects first, then prepares,
validates native engine/schema/revision, requested operation flags, source and
output SHA-256 hashes, finite metrics, ordered pen plan and page, and parses the
prepared SVG independently using the bundled `saxes` parser. It returns the
exact prepared bytes. `sourceReport` is the prior native inspection report.
The native `source.path` and `prepared.path` fields are **removed** from all
returned reports because their temporary files are deleted before resolution;
only their verified hashes are retained. Prepared page and stroke widths are
compared within 0.5 nanometres to account for the native writer's nine-decimal
millimetre formatting.

Limits default to 16 MiB input, 64 MiB report, 128 MiB prepared SVG, 64 KiB per
child output stream, and 125 seconds for the entire probe/inspect/prepare operation. Native report and SVG
files are opened without following symlinks and read through a running byte cap. `AbortSignal` cancels native
execution and waits for process termination before deleting temporary files.
Errors expose `kind`: `unavailable`, `input`, `io`, `cancelled`, `timeout`, or
`protocol`. Native input and I/O errors retain their stable native `code`.
The adapter does not retry work after a timeout or cancellation.

The package is distributed only as a private tarball built from this directory.
Pin the same tarball SHA-256 in both consumers' provenance records and lockfiles.
Its checked-in bundle of `saxes` and `xmlchars` makes the package usable in Node
and Bun without a registry lookup. No npm publication is intended.
