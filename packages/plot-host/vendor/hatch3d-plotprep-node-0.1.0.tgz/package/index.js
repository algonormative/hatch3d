import { createHash } from 'node:crypto';
import { performance } from 'node:perf_hooks';
import { isDeepStrictEqual } from 'node:util';
import { spawn } from 'node:child_process';
import { mkdtemp, writeFile, open, rm, realpath, stat, access } from 'node:fs/promises';
import { constants as fsConstants } from 'node:fs';
import { tmpdir } from 'node:os';
import { join, resolve, delimiter } from 'node:path';
import { SaxesParser } from './vendor/saxes.mjs';

const ENGINE = Object.freeze({name: 'plotprep', version: '0.1.0', vsvg_revision: 'b02060a761e9f0d177293fd7a6f01dd2a28ddae7'});
const SVG_NS = 'http://www.w3.org/2000/svg';
const INK_NS = 'http://www.inkscape.org/namespaces/inkscape';
const SHA = /^[a-f0-9]{64}$/;
const DEFAULTS = Object.freeze({inputBytes: 16 * 1024 * 1024, reportBytes: 64 * 1024 * 1024, outputBytes: 128 * 1024 * 1024, streamBytes: 64 * 1024, timeoutMs: 125_000});

export class PlotprepError extends Error {
  constructor(kind, message, {code, cause} = {}) {
    super(message, {cause});
    this.name = this.constructor.name;
    this.kind = kind;
    this.code = code ?? kind;
  }
}
export class PlotprepUnavailableError extends PlotprepError { constructor(message, detail) { super('unavailable', message, detail); } }
export class PlotprepInputError extends PlotprepError { constructor(message, detail) { super('input', message, detail); } }
export class PlotprepIoError extends PlotprepError { constructor(message, detail) { super('io', message, detail); } }
export class PlotprepCancelledError extends PlotprepError { constructor(message, detail) { super('cancelled', message, detail); } }
export class PlotprepTimeoutError extends PlotprepError { constructor(message, detail) { super('timeout', message, detail); } }
export class PlotprepProtocolError extends PlotprepError { constructor(message, detail) { super('protocol', message, detail); } }

function fail(message) { throw new PlotprepProtocolError(message); }
function checkpoint(signal, deadline) {
  if (signal?.aborted) throw new PlotprepCancelledError('plotprep call cancelled');
  if (performance.now() >= deadline) throw new PlotprepTimeoutError('plotprep operation exceeded total time limit');
}
function remainingMs(signal, deadline) { checkpoint(signal,deadline); return Math.max(1,Math.ceil(deadline-performance.now())); }
function assert(condition, message) { if (!condition) fail(message); }
function finitePositive(value, name, max) {
  if (typeof value !== 'number' || !Number.isFinite(value) || value <= 0 || value > max) throw new PlotprepInputError(`${name} must be finite and > 0, at most ${max}`);
  return value;
}
function finiteRange(value, name, min, max) {
  if (typeof value !== 'number' || !Number.isFinite(value) || value < min || value > max) throw new PlotprepInputError(`${name} must be finite in ${min}..${max}`);
  return value;
}
function integerCap(value, name, max) {
  if (!Number.isSafeInteger(value) || value < 1 || value > max) throw new PlotprepInputError(`${name} must be an integer in 1..${max}`);
  return value;
}
function sha256(bytes) { return createHash('sha256').update(bytes).digest('hex'); }
function equal(a, b) { return isDeepStrictEqual(a, b); }
function own(o, key) { return o && Object.hasOwn(o, key) ? o[key] : undefined; }
function closeMm(a, b) { return typeof a === 'number' && typeof b === 'number' && Math.abs(a-b) <= 0.500001e-9; }
function allowedAttrs(tag, names) { for (const a of Object.values(tag.attributes)) assert(names.has(a.name), `prepared XML has unsupported attribute: ${a.name}`); }
function finiteTree(root) {
  const todo = [root];
  let seen = 0;
  while (todo.length) {
    const value = todo.pop();
    if (++seen > 2_000_000) fail('report has too many values');
    if (typeof value === 'number' && !Number.isFinite(value)) fail('report contains a non-finite number');
    else if (value && typeof value === 'object') for (const child of Object.values(value)) todo.push(child);
  }
}
function normalizeOptions(options, mode) {
  if (options === null || typeof options !== 'object' || Array.isArray(options)) throw new PlotprepInputError('options must be an object');
  const allowed = new Set(mode === 'inspect' ? ['curveToleranceMm', 'signal'] : ['curveToleranceMm', 'sort', 'allowReverse', 'mergeToleranceMm', 'mergeScope', 'simplifyToleranceMm', 'signal']);
  for (const key of Object.keys(options)) if (!allowed.has(key)) throw new PlotprepInputError(`unknown ${mode} option: ${key}`);
  const o = {
    curveToleranceMm: options.curveToleranceMm === undefined ? 0.05 : finiteRange(options.curveToleranceMm, 'curveToleranceMm', 0.0001, 1),
    sort: mode === 'prepare' ? options.sort !== false : false,
    allowReverse: mode === 'prepare' ? options.allowReverse === true : false,
    mergeToleranceMm: options.mergeToleranceMm,
    mergeScope: options.mergeScope,
    simplifyToleranceMm: options.simplifyToleranceMm,
    signal: options.signal,
  };
  if (options.sort !== undefined && typeof options.sort !== 'boolean') throw new PlotprepInputError('sort must be boolean');
  if (options.allowReverse !== undefined && typeof options.allowReverse !== 'boolean') throw new PlotprepInputError('allowReverse must be boolean');
  if (o.allowReverse && !o.sort) throw new PlotprepInputError('allowReverse requires sorting');
  if (o.mergeToleranceMm !== undefined) finiteRange(o.mergeToleranceMm, 'mergeToleranceMm', 0, 100);
  if (o.simplifyToleranceMm !== undefined) finiteRange(o.simplifyToleranceMm, 'simplifyToleranceMm', 0, 10);
  if ((o.mergeToleranceMm === undefined) !== (o.mergeScope === undefined)) throw new PlotprepInputError('mergeToleranceMm and mergeScope must be supplied together');
  if (o.mergeScope !== undefined && !['named-parts','pen'].includes(o.mergeScope)) throw new PlotprepInputError('mergeScope must be named-parts or pen');
  if (o.signal !== undefined && !(o.signal instanceof AbortSignal)) throw new PlotprepInputError('signal must be an AbortSignal');
  return o;
}
function byteCopy(value, max) {
  if (!(value instanceof Uint8Array)) throw new PlotprepInputError('SVG input must be Uint8Array or Buffer');
  if (value.byteLength === 0 || value.byteLength > max) throw new PlotprepInputError(`SVG input must be 1..${max} bytes`);
  return Buffer.from(value);
}
function argsFor(mode, o) {
  const args = [mode, 'input.svg'];
  if (mode === 'prepare') args.push('--output', 'prepared.svg');
  args.push('--report', `${mode}.json`, '--curve-tolerance-mm', String(o.curveToleranceMm));
  if (mode === 'prepare') {
    if (!o.sort) args.push('--no-sort');
    if (o.allowReverse) args.push('--allow-reverse');
    if (o.mergeToleranceMm !== undefined) args.push('--merge-tolerance-mm', String(o.mergeToleranceMm), '--merge-scope', o.mergeScope);
    if (o.simplifyToleranceMm !== undefined) args.push('--simplify-tolerance-mm', String(o.simplifyToleranceMm));
  }
  return args;
}
function childRun(executable, args, cwd, limits, signal) {
  return new Promise((resolve, reject) => {
    if (signal?.aborted) { reject(new PlotprepCancelledError('plotprep call cancelled before spawn')); return; }
    let child;
    try { child = spawn(executable, args, {cwd, shell: false, stdio: ['ignore','pipe','pipe'], windowsHide: true}); }
    catch (cause) { reject(new PlotprepUnavailableError('could not spawn plotprep', {cause})); return; }
    const stdout = [], stderr = [];
    let outSize = 0, errSize = 0, stopped = null, settled = false;
    function stop(error) { if (!stopped) { stopped = error; child.kill('SIGKILL'); } }
    const timer = setTimeout(() => stop(new PlotprepTimeoutError(`plotprep exceeded ${limits.timeoutMs} ms`)), limits.timeoutMs);
    const abort = () => stop(new PlotprepCancelledError('plotprep call cancelled'));
    signal?.addEventListener('abort', abort, {once: true});
    child.stdout.on('data', chunk => { outSize += chunk.length; if (outSize > limits.streamBytes) stop(new PlotprepProtocolError('plotprep stdout exceeded bound')); else stdout.push(chunk); });
    child.stderr.on('data', chunk => { errSize += chunk.length; if (errSize > limits.streamBytes) stop(new PlotprepProtocolError('plotprep stderr exceeded bound')); else stderr.push(chunk); });
    child.on('error', cause => {
      if (cause.code === 'ENOENT' || cause.code === 'EACCES') stop(new PlotprepUnavailableError('plotprep executable unavailable', {cause}));
      else stop(new PlotprepIoError('plotprep process failed', {cause}));
    });
    child.on('close', (code, sig) => {
      if (settled) return;
      settled = true; clearTimeout(timer); signal?.removeEventListener('abort', abort);
      if (stopped) { reject(stopped); return; }
      const output = Buffer.concat(stdout).toString('utf8');
      const errors = Buffer.concat(stderr).toString('utf8');
      if (sig || code === null) { reject(new PlotprepProtocolError(`plotprep terminated by ${sig ?? 'unknown signal'}`)); return; }
      if (code === 0) { resolve({stdout: output, stderr: errors}); return; }
      let data;
      try { data = JSON.parse(errors.trim().split('\n').at(-1)); } catch {}
      const nativeCode = typeof data?.error?.code === 'string' ? data.error.code : `exit_${code}`;
      const message = typeof data?.error?.message === 'string' ? data.error.message : `plotprep exited ${code}`;
      const detail = {code: nativeCode};
      if (code === 2) reject(new PlotprepInputError(message, detail));
      else if (code === 3) reject(new PlotprepIoError(message, detail));
      else reject(new PlotprepProtocolError(`${message} (exit ${code})`, detail));
    });
  });
}
async function boundedFile(path, max, signal, deadline) {
  checkpoint(signal,deadline);
  let file;
  try { file = await open(path, fsConstants.O_RDONLY | fsConstants.O_NOFOLLOW); }
  catch (cause) {
    if (cause.code === 'ENOENT' || cause.code === 'ELOOP') throw new PlotprepProtocolError('native artifact missing or symlinked');
    throw new PlotprepIoError('could not open native artifact', {cause});
  }
  try {
    let info;
    try { info = await file.stat(); } catch (cause) { throw new PlotprepIoError('could not stat native artifact', {cause}); }
    assert(info.isFile() && info.size > 0 && info.size <= max, 'native artifact size or type invalid');
    const chunks=[];
    let size=0;
    const buffer=Buffer.allocUnsafe(64 * 1024);
    while (true) {
      checkpoint(signal,deadline);
      let read;
      try { read = await file.read(buffer,0,Math.min(buffer.length,max-size+1),null); }
      catch (cause) { throw new PlotprepIoError('could not read native artifact', {cause}); }
      if (read.bytesRead === 0) break;
      size += read.bytesRead;
      assert(size <= max, 'native artifact grew beyond byte limit');
      chunks.push(Buffer.from(buffer.subarray(0,read.bytesRead)));
    }
    checkpoint(signal,deadline);
    assert(size > 0 && size === info.size, 'native artifact changed during read');
    return Buffer.concat(chunks,size);
  } finally { await file.close(); }
}
function number(v, label, {positive = false, integer = false} = {}) {
  assert(typeof v === 'number' && Number.isFinite(v) && (!positive || v > 0) && (!integer || Number.isSafeInteger(v)), `${label} invalid`);
  return v;
}
function metrics(m, label, requirePenUp = true) {
  assert(m && typeof m === 'object', `${label} missing`);
  for (const field of ['paths','segments','vertices']) { number(m[field], `${label}.${field}`, {integer: true}); assert(m[field] >= 0, `${label}.${field} negative`); }
  for (const field of (requirePenUp ? ['drawn_length_mm','pen_up_mm'] : ['drawn_length_mm'])) { number(m[field], `${label}.${field}`); assert(m[field] >= 0, `${label}.${field} negative`); }
}
function penPlan(report) {
  assert(Array.isArray(report.pens) && report.pens.length <= 1000, 'pen plan missing or too large');
  let prior = 0;
  return report.pens.map((p, i) => {
    assert(p && typeof p === 'object', `pen ${i} missing`);
    number(p.layer_number, `pen ${i} number`, {integer:true});
    assert(p.layer_number > prior && p.layer_number <= 1000, 'pen numbers not strictly increasing'); prior = p.layer_number;
    number(p.passes, `pen ${i} passes`, {integer:true}); assert(p.passes >= 1 && p.passes <= 100, `pen ${i} passes out of range`);
    number(p.stroke_width_mm, `pen ${i} width`, {positive:true});
    assert(p.stroke_width_mm >= 1e-6 && p.stroke_width_mm <= 1000, `pen ${i} width out of range`);
    assert(typeof p.color === 'string' && /^#[0-9a-fA-F]{6}$/.test(p.color), `pen ${i} color invalid`);
    assert(typeof p.label === 'string' && (p.source_label === null || typeof p.source_label === 'string'), `pen ${i} label invalid`);
    for (const field of ['id','pen_id']) assert(p[field] === null || typeof p[field] === 'string', `pen ${i} ${field} invalid`);
    for (const field of ['path_count_before','path_count_after']) { number(p[field], `pen ${i} ${field}`, {integer:true}); assert(p[field] >= 0, `pen ${i} ${field} negative`); }
    return {layer_number:p.layer_number, id:p.id, pen_id:p.pen_id, label:p.label, source_label:p.source_label, color:p.color.toLowerCase(), stroke_width_mm:p.stroke_width_mm, passes:p.passes, path_count_before:p.path_count_before, path_count_after:p.path_count_after};
  });
}
function validateReport(data, mode, inputHash, o, outputBytes) {
  assert(data && typeof data === 'object' && !Array.isArray(data), 'report must be an object');
  finiteTree(data);
  assert(data.schema_version === 1 && equal(data.engine, ENGINE), 'native engine/schema/revision mismatch');
  assert(data.source?.sha256 === inputHash && SHA.test(data.source.sha256), 'source hash mismatch');
  assert(data.prepared === null || (mode === 'prepare' && typeof data.prepared === 'object'), 'prepared report field mismatch');
  if (mode === 'prepare') assert(data.prepared?.sha256 === sha256(outputBytes) && SHA.test(data.prepared.sha256), 'prepared hash mismatch');
  number(data.page?.width_mm, 'page width', {positive:true}); number(data.page?.height_mm, 'page height', {positive:true});
  const pens = penPlan(data);
  const n = data.operations?.normalization;
  assert(n && n.requested_curve_tolerance_mm === o.curveToleranceMm, 'normalization request mismatch');
  if (n.curve_tolerance_mm !== null) { number(n.curve_tolerance_mm, 'achieved curve tolerance', {positive:true}); assert(n.curve_tolerance_mm <= o.curveToleranceMm, 'achieved tolerance exceeds request'); }
  const cleanup = data.operations?.cleanup, sort = data.operations?.sort;
  assert(cleanup && sort, 'operation report missing');
  assert(cleanup.enabled === (mode === 'prepare' && (o.mergeToleranceMm !== undefined || o.simplifyToleranceMm !== undefined)), 'cleanup operation mismatch');
  assert(cleanup.enabled ? cleanup.result !== null : cleanup.result === null, 'cleanup result mismatch');
  assert(cleanup.merge_tolerance_mm === (o.mergeToleranceMm ?? null) && cleanup.merge_scope === (o.mergeScope === 'named-parts' ? 'named_parts' : o.mergeScope === 'pen' ? 'whole_pen' : null) && cleanup.simplify_tolerance_mm === (o.simplifyToleranceMm ?? null), 'cleanup options mismatch');
  assert(sort.enabled === (mode === 'prepare' && o.sort) && sort.allow_reverse === o.allowReverse, 'sort operation mismatch');
  assert(sort.enabled ? sort.result !== null : sort.result === null, 'sort result mismatch');
  if (sort.enabled) { number(sort.objective_before_mm, 'sort before'); number(sort.objective_after_mm, 'sort after'); assert(sort.objective_after_mm <= sort.objective_before_mm + 1e-7, 'sort made travel worse'); }
  for (const [key,m] of Object.entries(data.geometry ?? {})) metrics(m, `geometry.${key}`,key !== 'original');
  assert(data.geometry?.original && data.geometry?.normalized && data.geometry?.after_cleanup && data.geometry?.output && data.geometry.original.basis === 'physical_source_strokes_before_clip_dash', 'geometry stages or original basis missing');
  for (const [key,m] of Object.entries(data.pass_weighted ?? {})) metrics(m, `pass_weighted.${key}`);
  assert(data.pass_weighted?.before && data.pass_weighted?.after_cleanup && data.pass_weighted?.output, 'pass-weighted metrics missing');
  assert(Array.isArray(data.parts) && Array.isArray(data.diagnostics), 'parts/diagnostics missing');
  for (const diagnostic of data.diagnostics) assert(diagnostic && ['info','warning','error'].includes(diagnostic.severity) && typeof diagnostic.code === 'string' && diagnostic.code.length > 0 && (diagnostic.element === null || typeof diagnostic.element === 'string') && typeof diagnostic.message === 'string', 'diagnostic invalid');
  assert(data.geometry.normalized.paths === pens.reduce((x,p)=>x+p.path_count_before,0), 'normalized path count mismatch');
  assert(data.geometry.output.paths === pens.reduce((x,p)=>x+p.path_count_after,0), 'output path count mismatch');
  assert(data.pass_weighted.output.paths === pens.reduce((x,p)=>x+p.path_count_after*p.passes,0), 'pass-weighted path count mismatch');
  const travel=data.travel;
  assert(travel?.objective === 'geometric_pen_up_mm' && travel.per_pen_restart === true && travel.return_home_leg === false && equal(travel.origin_mm,[0,0]), 'travel definition mismatch');
  for (const [field, stage] of [['before_mm','normalized'],['after_cleanup_mm','after_cleanup'],['after_mm','output']]) assert(travel[field] === data.geometry[stage].pen_up_mm, `travel ${field} mismatch`);
  assert(Array.isArray(travel.pens) && travel.pens.length === pens.length, 'per-pen travel mismatch');
  for (let i=0;i<pens.length;i++) assert(travel.pens[i].layer_number === pens[i].layer_number, `travel pen ${i} order mismatch`);
  for (const part of data.parts) { assert(part && Number.isSafeInteger(part.layer_number) && pens.some(p=>p.layer_number===part.layer_number) && typeof part.part_id === 'string' && (part.source_element_id === null || typeof part.source_element_id === 'string'), 'part plan invalid'); for(const f of ['path_count_before','path_count_after']) assert(Number.isSafeInteger(part[f]) && part[f]>=0, 'part path count invalid'); }
  const safe = structuredClone(data);
  delete safe.source.path;
  if (safe.prepared) delete safe.prepared.path;
  return {report:safe, pens};
}
function mm(value, label) {
  assert(typeof value === 'string' && /^(?:0|[0-9]+(?:\.[0-9]+)?)mm$/.test(value), `${label} not mm`);
  return number(Number(value.slice(0,-2)), label, {positive:true});
}
function decimal(value, label) {
  assert(typeof value === 'string' && /^(?:0|[0-9]+(?:\.[0-9]+)?)$/.test(value), `${label} invalid`);
  return number(Number(value), label);
}
function preparedPlan(bytes) {
  const xml = bytes.toString('utf8');
  const parser = new SaxesParser({xmlns:true});
  const stack = [];
  const pens = [];
  let page, rootSeen = false, elements = 0;
  parser.on('doctype', () => fail('prepared XML contains doctype'));
  parser.on('processinginstruction', () => fail('prepared XML contains processing instruction'));
  parser.on('text', text => { if (text.trim()) fail('prepared XML contains text content'); });
  parser.on('opentag', tag => {
    assert(++elements <= 1_000_000, 'prepared XML element limit exceeded');
    assert(tag.uri === SVG_NS, 'prepared SVG namespace mismatch');
    const attrs = tag.attributes;
    const a = name => own(attrs, name)?.value;
    const parent = stack.at(-1)?.type;
    if (!parent) {
      assert(!rootSeen && tag.local === 'svg', 'prepared XML root invalid'); rootSeen = true;
      allowedAttrs(tag, new Set(['xmlns','xmlns:inkscape','width','height','viewBox','data-plotprep-format']));
      assert(a('data-plotprep-format') === '1', 'prepared format marker invalid');
      const width = mm(a('width'), 'prepared width'), height = mm(a('height'), 'prepared height');
      const vb = a('viewBox')?.trim().split(/\s+/).map(Number);
      assert(vb?.length === 4 && vb.every(Number.isFinite) && vb[0] === 0 && vb[1] === 0 && vb[2] === width && vb[3] === height, 'prepared viewBox invalid');
      page = {width_mm:width,height_mm:height}; stack.push({type:'root'}); return;
    }
    if (parent === 'root') {
      assert(tag.local === 'g' && own(attrs,'inkscape:groupmode')?.uri === INK_NS && a('inkscape:groupmode') === 'layer', 'prepared layer invalid');
      allowedAttrs(tag, new Set(['inkscape:groupmode','inkscape:label','id','data-source-label','data-pen-id','data-passes','fill','stroke','stroke-width','stroke-linecap','stroke-linejoin','stroke-miterlimit']));
      const label = a('inkscape:label'); assert(typeof label === 'string', 'prepared label missing');
      const numberMatch = /^(\d+)(?:\s|-|$)/.exec(label);
      assert(numberMatch, 'prepared label lacks layer number');
      const p = {layer_number:Number(numberMatch[1]), id:a('id')??null, pen_id:a('data-pen-id')??null, label, source_label:a('data-source-label')??undefined, color:a('stroke')?.toLowerCase(), stroke_width_mm:decimal(a('stroke-width'),'prepared stroke width'), passes:Number(a('data-passes')), path_count_after:0};
      assert(a('fill') === 'none' && Number.isSafeInteger(p.passes) && p.passes >= 1 && p.passes <= 100, 'prepared pen style invalid');
      assert(['butt','round','square'].includes(a('stroke-linecap')) && ['miter','round','bevel'].includes(a('stroke-linejoin')) && decimal(a('stroke-miterlimit'),'prepared miter limit') >= 1, 'prepared line style invalid');
      assert(pens.length < 1000, 'prepared XML pen limit exceeded'); pens.push(p); stack.push({type:'layer',pen:p}); return;
    }
    if (parent === 'layer' && tag.local === 'g') { allowedAttrs(tag, new Set(['data-part-id'])); assert(typeof a('data-part-id') === 'string', 'prepared part missing id'); stack.push({type:'part',pen:stack.at(-1).pen}); return; }
    if ((parent === 'layer' || parent === 'part') && tag.local === 'path') { allowedAttrs(tag, new Set(['d','id','data-plotprep-ancestry','data-source-id','data-segment-index'])); assert(typeof a('d') === 'string' && a('d').length > 0 && typeof a('data-plotprep-ancestry') === 'string', 'prepared path missing geometry or ancestry');
      let ancestry; try { ancestry=JSON.parse(a('data-plotprep-ancestry')); } catch { fail('prepared path ancestry invalid JSON'); }
      assert(Array.isArray(ancestry) && ancestry.length > 0 && ancestry.length <= 100000, 'prepared path ancestry invalid');
      stack.at(-1).pen.path_count_after++; stack.push({type:'path'}); return; }
    fail('prepared XML has unsupported hierarchy');
  });
  parser.on('closetag', () => { stack.pop(); });
  try { parser.write(xml).close(); } catch (cause) { if (cause instanceof PlotprepError) throw cause; throw new PlotprepProtocolError('prepared SVG XML invalid', {cause}); }
  assert(rootSeen && stack.length === 0, 'prepared XML incomplete');
  return {page,pens};
}
function comparePlans(inspect, prepare) {
  assert(equal(inspect.report.page, prepare.report.page), 'page changed during preparation');
  assert(inspect.pens.length === prepare.pens.length, 'pen count changed during preparation');
  for (let i=0;i<inspect.pens.length;i++) {
    const a=inspect.pens[i], b=prepare.pens[i];
    for (const key of ['layer_number','id','pen_id','label','source_label','color','stroke_width_mm','passes','path_count_before']) assert(a[key] === b[key], `source pen ${i} ${key} changed during preparation`);
  }
  assert(equal(inspect.report.operations.normalization, prepare.report.operations.normalization), 'source normalization changed during preparation');
  assert(equal(inspect.report.geometry.original, prepare.report.geometry.original) && equal(inspect.report.geometry.normalized, prepare.report.geometry.normalized), 'source geometry changed during preparation');
}
function compareSvg(plan, report) {
  assert(closeMm(plan.page.width_mm, report.report.page.width_mm) && closeMm(plan.page.height_mm, report.report.page.height_mm), 'prepared page differs from report');
  assert(plan.pens.length === report.pens.length, 'prepared pen count differs from report');
  for (let i=0;i<plan.pens.length;i++) {
    const a=plan.pens[i], b=report.pens[i];
    for (const key of ['layer_number','id','pen_id','label','color','passes','path_count_after']) assert(a[key] === b[key], `prepared pen ${i} ${key} differs from report`);
    assert(closeMm(a.stroke_width_mm,b.stroke_width_mm), `prepared pen ${i} stroke_width_mm differs from report`);
    assert(a.source_label === undefined ? (b.source_label === null || b.source_label === b.label) : a.source_label === b.source_label, `prepared pen ${i} source_label differs from report`);
  }
}
export function createPlotprepClient(config = {}) {
  if (config === null || typeof config !== 'object' || Array.isArray(config)) throw new PlotprepInputError('client config must be object');
  const keys = new Set(['executable','timeoutMs','maxInputBytes','maxReportBytes','maxOutputBytes','maxStreamBytes']);
  for (const key of Object.keys(config)) if (!keys.has(key)) throw new PlotprepInputError(`unknown client config: ${key}`);
  const executable = config.executable ?? 'plotprep';
  if (typeof executable !== 'string' || !executable || executable.includes('\0')) throw new PlotprepInputError('executable must be a nonempty path or command');
  const limits = {
    timeoutMs: config.timeoutMs === undefined ? DEFAULTS.timeoutMs : integerCap(config.timeoutMs,'timeoutMs',300_000),
    inputBytes: config.maxInputBytes === undefined ? DEFAULTS.inputBytes : integerCap(config.maxInputBytes,'maxInputBytes',DEFAULTS.inputBytes),
    reportBytes: config.maxReportBytes === undefined ? DEFAULTS.reportBytes : integerCap(config.maxReportBytes,'maxReportBytes',DEFAULTS.reportBytes),
    outputBytes: config.maxOutputBytes === undefined ? DEFAULTS.outputBytes : integerCap(config.maxOutputBytes,'maxOutputBytes',DEFAULTS.outputBytes),
    streamBytes: config.maxStreamBytes === undefined ? DEFAULTS.streamBytes : integerCap(config.maxStreamBytes,'maxStreamBytes',DEFAULTS.streamBytes),
  };
  const creationCwd=process.cwd(), creationPath=process.env.PATH ?? '';
  const candidates=executable.includes('/') ? [resolve(creationCwd,executable)] : creationPath.split(delimiter).map(entry=>resolve(creationCwd,entry || '.',executable));
  let resolvedExecutablePromise;
  async function resolvedExecutable() {
    if (!resolvedExecutablePromise) resolvedExecutablePromise=(async()=>{
      for (const candidate of candidates) {
        try {
          const canonical=await realpath(candidate);
          const info=await stat(canonical);
          if (!info.isFile()) continue;
          await access(canonical,fsConstants.X_OK);
          return canonical;
        } catch { /* Continue PATH search. */ }
      }
      throw new PlotprepUnavailableError('plotprep executable unavailable or not executable');
    })().catch(error=>{resolvedExecutablePromise=undefined;throw error;});
    return resolvedExecutablePromise;
  }
  let probed = false;
  async function probeWithin(signal, deadline) {
    checkpoint(signal,deadline);
    const path=await resolvedExecutable();
    checkpoint(signal,deadline);
    const {stdout} = await childRun(path, ['version','--json'], undefined, {...limits,timeoutMs:remainingMs(signal,deadline)}, signal);
    checkpoint(signal,deadline);
    let value;
    try { value = JSON.parse(stdout); } catch (cause) { throw new PlotprepProtocolError('native version response is not JSON', {cause}); }
    assert(value.schema_version === 1 && equal(value.engine, ENGINE), 'native version/schema/revision mismatch');
    checkpoint(signal,deadline);
    probed = true;
    return Object.freeze({...ENGINE, schema_version:1});
  }
  async function probe({signal}={}) {
    if (signal !== undefined && !(signal instanceof AbortSignal)) throw new PlotprepInputError('signal must be an AbortSignal');
    return probeWithin(signal,performance.now()+limits.timeoutMs);
  }
  async function ensureProbe(signal, deadline) { if (!probed) await probeWithin(signal,deadline); }

  async function operation(mode, input, options={}) {
    const deadline=performance.now()+limits.timeoutMs;
    const o=normalizeOptions(options,mode), bytes=byteCopy(input,limits.inputBytes);
    checkpoint(o.signal,deadline);
    await ensureProbe(o.signal,deadline);
    const nativePath=await resolvedExecutable();
    checkpoint(o.signal,deadline);
    const inputHash=sha256(bytes);
    checkpoint(o.signal,deadline);
    let dir;
    try { dir=await mkdtemp(join(tmpdir(),'plotprep-node-')); } catch (cause) { throw new PlotprepIoError('could not create private plotprep work directory', {cause}); }
    let primaryError, result;
    try {
      checkpoint(o.signal,deadline);
      try { await writeFile(join(dir,'input.svg'),bytes,{flag:'wx',mode:0o600}); } catch (cause) { throw new PlotprepIoError('could not write private SVG input', {cause}); }
      checkpoint(o.signal,deadline);
      const readReport = async name => {
        const content=await boundedFile(join(dir,`${name}.json`),limits.reportBytes,o.signal,deadline);
        let parsed;
        try { parsed=JSON.parse(content.toString('utf8')); } catch (cause) { throw new PlotprepProtocolError('native report is not JSON', {cause}); }
        checkpoint(o.signal,deadline);
        return parsed;
      };
      await childRun(nativePath,argsFor('inspect',o),dir,{...limits,timeoutMs:remainingMs(o.signal,deadline)},o.signal);
      checkpoint(o.signal,deadline);
      const inspected=validateReport(await readReport('inspect'),'inspect',inputHash,{...o,allowReverse:false,mergeToleranceMm:undefined,mergeScope:undefined,simplifyToleranceMm:undefined});
      checkpoint(o.signal,deadline);
      if (mode==='inspect') result={report:inspected.report};
      else {
        await childRun(nativePath,argsFor('prepare',o),dir,{...limits,timeoutMs:remainingMs(o.signal,deadline)},o.signal);
        checkpoint(o.signal,deadline);
        const output=await boundedFile(join(dir,'prepared.svg'),limits.outputBytes,o.signal,deadline);
        const prepared=validateReport(await readReport('prepare'),'prepare',inputHash,o,output);
        checkpoint(o.signal,deadline);
        comparePlans(inspected,prepared);
        compareSvg(preparedPlan(output),prepared);
        checkpoint(o.signal,deadline);
        result={bytes:output, report:prepared.report, sourceReport:inspected.report};
      }
    } catch (error) { primaryError=error; throw error; } finally {
      try { await rm(dir,{recursive:true,force:true}); } catch (cause) { if (!primaryError) throw new PlotprepIoError('could not remove private plotprep work directory', {cause}); }
    }
    checkpoint(o.signal,deadline);
    return result;
  }

  return Object.freeze({probe,inspectSvg:(bytes,options)=>operation('inspect',bytes,options),prepareSvg:(bytes,options)=>operation('prepare',bytes,options)});
}
export const nativeIdentity = ENGINE;
