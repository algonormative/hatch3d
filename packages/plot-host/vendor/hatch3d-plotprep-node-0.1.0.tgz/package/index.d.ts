export type PlotprepErrorKind = 'unavailable' | 'input' | 'io' | 'cancelled' | 'timeout' | 'protocol';
export class PlotprepError extends Error { readonly kind: PlotprepErrorKind; readonly code: string; }
export class PlotprepUnavailableError extends PlotprepError {}
export class PlotprepInputError extends PlotprepError {}
export class PlotprepIoError extends PlotprepError {}
export class PlotprepCancelledError extends PlotprepError {}
export class PlotprepTimeoutError extends PlotprepError {}
export class PlotprepProtocolError extends PlotprepError {}

export interface ClientConfig {
  executable?: string;
  timeoutMs?: number;
  maxInputBytes?: number;
  maxReportBytes?: number;
  maxOutputBytes?: number;
  maxStreamBytes?: number;
}
export interface InspectOptions { curveToleranceMm?: number; signal?: AbortSignal; }
export interface PrepareOptions extends InspectOptions {
  sort?: boolean;
  allowReverse?: boolean;
  mergeToleranceMm?: number;
  mergeScope?: 'named-parts' | 'pen';
  simplifyToleranceMm?: number;
}
export interface PhysicalPen {
  layer_number: number;
  id: string | null;
  pen_id: string | null;
  label: string;
  source_label: string | null;
  color: string;
  stroke_width_mm: number;
  passes: number;
  path_count_before: number;
  path_count_after: number;
}
export interface MetricCounts {
  paths: number;
  segments: number;
  vertices: number;
  drawn_length_mm: number;
  pen_up_mm?: number;
}
export interface PlotprepReport {
  schema_version: 1;
  engine: {name: 'plotprep'; version: '0.1.0'; vsvg_revision: 'b02060a761e9f0d177293fd7a6f01dd2a28ddae7'};
  source: {sha256: string};
  prepared: {sha256: string} | null;
  page: {width_mm: number; height_mm: number};
  pens: PhysicalPen[];
  parts: Array<{layer_number: number; part_id: string; source_element_id: string | null; path_count_before: number; path_count_after: number}>;
  geometry: {original: MetricCounts & {basis: string}; normalized: MetricCounts; after_cleanup: MetricCounts; output: MetricCounts};
  operations: {
    normalization: {requested_curve_tolerance_mm: number; curve_tolerance_mm: number | null; [key: string]: unknown};
    cleanup: {enabled: boolean; merge_tolerance_mm: number | null; merge_scope: 'named_parts' | 'whole_pen' | null; simplify_tolerance_mm: number | null; result: Record<string, unknown> | null};
    sort: {enabled: boolean; allow_reverse: boolean; objective_before_mm: number; objective_after_mm: number; result: Record<string, unknown> | null};
  };
  travel: Record<string, unknown>;
  pass_weighted: {before: MetricCounts; after_cleanup: MetricCounts; output: MetricCounts};
  diagnostics: Array<{severity: string; code: string; element: string | null; message: string}>;
}
export interface PlotprepClient {
  probe(options?: {signal?: AbortSignal}): Promise<{name:'plotprep'; version:'0.1.0'; vsvg_revision:'b02060a761e9f0d177293fd7a6f01dd2a28ddae7'; schema_version:1}>;
  inspectSvg(svg: Uint8Array, options?: InspectOptions): Promise<{report: PlotprepReport}>;
  prepareSvg(svg: Uint8Array, options?: PrepareOptions): Promise<{bytes: Uint8Array; report: PlotprepReport; sourceReport: PlotprepReport}>;
}
export function createPlotprepClient(config?: ClientConfig): PlotprepClient;
export const nativeIdentity: Readonly<{name:'plotprep'; version:'0.1.0'; vsvg_revision:'b02060a761e9f0d177293fd7a6f01dd2a28ddae7'}>;
