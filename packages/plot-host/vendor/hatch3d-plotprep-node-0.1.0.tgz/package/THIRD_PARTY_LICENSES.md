# Third-party licenses

The vendored XML parser bundle `vendor/saxes.mjs` contains `saxes` 6.0.0
(ISC, Louis-Dominique Dubeau and contributors) and `xmlchars` 2.2.0 (MIT,
Louis-Dominique Dubeau and contributors). See their complete notices in
`vendor/SAXES-LICENSE.txt` and `vendor/XMLCHARS-LICENSE.txt`; exact upstream
package integrity values and build provenance are in `vendor/README.md`.

The native `plotprep` executable is a separate Rust artifact. It pins `vsvg` to
revision `b02060a761e9f0d177293fd7a6f01dd2a28ddae7`; its license is
included as `VSVG-LICENSE.txt` for provenance. This Node package does not
bundle the native executable.
